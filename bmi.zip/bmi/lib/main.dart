import 'dart:math';
import 'package:flutter/material.dart';
import 'boxes.dart';
import 'calculatepage.dart';

void main() {
  runApp(const MyApp());
}

TextStyle textingstyle = TextStyle(
  fontSize: 30,
  color: Colors.white,
  fontWeight: FontWeight.bold
);

const Color activecolor = Colors.white38;
const Color inactivecolor = Colors.blueGrey;

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Ui(),
    );
  }
}

class Ui extends StatefulWidget {
  const Ui({super.key});

  @override
  State<Ui> createState() => _UiState();
}


enum genders{
  male,
  female
}


class _UiState extends State<Ui> {

  genders? Selectedgender;
  int height = 1;
  int age = 1;
  int weight = 1;



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text('BMI Calculator',
        style: textingstyle,
        ),
      ),
      body: Column(
        children: [
          Row(
            children: [
              Expanded(child: GestureDetector(
                onTap: (){
                  setState(() {
                    Selectedgender = genders.male;
                  });
                },
                child: ReusableCard(
                  cardchild: Cardchild(icon: Icon(Icons.male,
                  size: 70,
                  ), text: Text('MALE',
                    style: textingstyle,
                  )),
                  colors: Selectedgender == genders.male ? activecolor : inactivecolor
                ),
              )),
              Expanded(child: GestureDetector(
                onTap: (){
                  setState(() {
                    Selectedgender = genders.female;
                  });
                },
                child: ReusableCard(
                  cardchild: Cardchild(
                    icon: Icon(Icons.female,
                  size: 70,
                  ), text: Text('FEMALE',
                  style: textingstyle,
                  ),),
                  colors: Selectedgender == genders.female ? activecolor : inactivecolor
                ),
              ))
            ],
          ),
          Row(
            children: [
              Expanded(
                child: ReusableCard(
                  cardchild: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text('HEIGHT',
                      style: textingstyle,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text('$height',
                          style: textingstyle,
                          ),
                          Text('cm',
                          style: textingstyle,
                          ),
                        ],
                      ),
                      Slider(value:
                          height.toDouble(),
                      min: 0,
                      max: 180,
                          onChanged: (double newValue){
                        setState(() {
                          height = newValue.round();
                        });
                      }
                      )

                    ],
                  ),
                  colors: Colors.blueGrey,
                ),
              ),
            ],
          ),
          Row(
            children: [
              Expanded(child: ReusableCard(
                cardchild: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text('AGE',
                      style: textingstyle,),

                    Text('$age',
                    style: textingstyle,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        GestureDetector(
                          onTap: (){
                            setState(() {
                              age--;
                            });
                          },
                          child: Icon(Icons.remove,
                          size: 40,
                          ),
                        ),
                        GestureDetector(
                          onTap: (){
                            setState(() {
                              age++;
                            });
                          },
                          child: Icon(Icons.add,
                            size: 40,
                          ),
                        )],
                    ),

                  ],
                ),
                colors: Colors.blueGrey,
              )),
              Expanded(child: ReusableCard(
                cardchild: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text('WEIGHT',
                      style: textingstyle,),

                    Text('$weight',
                      style: textingstyle,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        GestureDetector(
                          onTap: (){
                            setState(() {
                              weight--;
                            });
                          },
                          child: Icon(Icons.remove,
                            size: 40,
                          ),
                        ),
                        GestureDetector(
                          onTap: (){
                            setState(() {
                              weight++;
                            });
                          },
                          child: Icon(Icons.add,
                            size: 40,
                          ),
                        )],
                    ),

                  ],
                ),
                colors: Colors.blueGrey,
              ))
            ],
          ),
          Expanded(
            child: GestureDetector(
              onTap: (){
                Navigator.push(context, MaterialPageRoute(builder: (context) => Calculatepage()));
              },
              child: ReusableCard(colors: inactivecolor,

                  cardchild: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text('CALCULATE:',
                      textAlign: TextAlign.center,
                      style: textingstyle,

                      ),
                    ],
                  )
              ),
            ),
          ),
        ],
        
      ),
      );
  }
}


import 'package:flutter/material.dart';

class ReusableCard extends StatelessWidget {
  ReusableCard({required this.colors, required this.cardchild,});
  final Color colors;
  Widget cardchild;



  @override
  Widget build(BuildContext context) {
    return Container(
      width: 400,
      height: 200,
      child: cardchild,
      margin: EdgeInsets.all(6.0),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
            color: colors,
      ),
    );
  }
}


class Cardchild extends StatelessWidget {
  Cardchild({required this.icon, required this.text});

  Icon icon;
  Text text;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        icon,
        text,
      ],
    );
  }
}
